package br.com.Classes;

import javax.persistence.Column;
import javax.persistence.Entity;

@SuppressWarnings("serial")
@Entity
public class Carro extends GeradorID {
	
	
	@Column(nullable = false,length = 15)
	private String Descricao;
	
	
	@Column(nullable = false,length = 8)
	private String Placa;


	public String getDescricao() {
		return Descricao;
	}


	public void setDescricao(String descricao) {
		Descricao = descricao;
	}


	public String getPlaca() {
		return Placa;
	}


	public void setPlaca(String placa) {
		Placa = placa;
	}
	
	public void Carro() {
		this.Descricao="";
		this.Placa="";
		
	}
	
	
	
	

}
