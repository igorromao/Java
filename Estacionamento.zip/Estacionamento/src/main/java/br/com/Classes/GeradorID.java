package br.com.Classes;

import java.io.Serializable;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

@SuppressWarnings("serial")	//anotacao para sumir os warnings

@MappedSuperclass  //anotacao para dizer que esta classe nao correponde a uma tabela
public class GeradorID implements Serializable {   //classe para gerar os id de todas as classes

	@Id  //anotacao para chave primaria
	@GeneratedValue(strategy = GenerationType.AUTO) //dando o auto increment 
	
	
   private int iDAluguel;
   
   public int getiDAluguel() {
	   
	   
	return iDAluguel;
}

public void setiDAluguel(int iDAluguel) {
	this.iDAluguel = iDAluguel;
}
   
   
   
  
}
   
   


