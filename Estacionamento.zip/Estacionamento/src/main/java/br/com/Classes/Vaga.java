package br.com.Classes;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.Table;

import br.com.estacionamento.bean.VagaBean;
import br.com.estacionamento.dao.VagaDAO;


@SuppressWarnings("serial")
@Entity //anotacao para falar que esta classe � uma tabela no banco

public class Vaga extends GeradorID {
	
	
	@Column
	private String Descricao;
	




	public String getDescricao() {
		return Descricao;
	}




	public void setDescricao(String descricao) {
		Descricao = descricao;
	}



	
	

	
	
	

}
