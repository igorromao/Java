package br.com.Classes;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@SuppressWarnings("serial")
@Entity
public class Aluguel extends GeradorID {
	
	
	@Column(nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date DataEntrada;
	
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	private Date DataSaida;
	
	
	@ManyToOne
	@JoinColumn(nullable = false)
	private Vaga Vaga;
	
	@ManyToOne
	@JoinColumn(nullable = false)
	private Carro Carro;

	public Date getDataEntrada() {
		return DataEntrada;
	}

	public void setDataEntrada(Date dataEntrada) {
		DataEntrada = dataEntrada;
	}

	public Date getDataSaida() {
		return DataSaida;
	}

	public void setDataSaida(Date dataSaida) {
		DataSaida = dataSaida;
	}

	public Vaga getVaga() {
		return Vaga;
	}

	public void setVaga(Vaga vaga) {
		Vaga = vaga;
	}

	public Carro getCarro() {
		return Carro;
	}

	public void setCarro(Carro carro) {
		Carro = carro;
	}
	
	
	
	
	
	
	

}
