package br.com.main;

import org.hibernate.Session;

import br.com.estacionamento.util.HibernateUtil;

public class EstacionamentoTeste {
	public static void main(String[] args) {
		
		Session sessao =HibernateUtil.getSessionFactory().openSession(); //capturante uma sessao aberta apartir da classe HibernateUtil
		
		sessao.close(); //fechando a sessao
		HibernateUtil.getSessionFactory().close();
	}

}
