package br.com.estacionamento.dao;
import java.lang.reflect.ParameterizedType;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import br.com.estacionamento.util.HibernateUtil;




public class GenericDAO<Entidade> { //<Entidade> para puxar para o pacote "classes", criando uma classe só para salvar todas as 3 classes .
	
	
	private Class<Entidade> classe;
	
	@SuppressWarnings("unchecked")
	public GenericDAO() {     //metodo para falar pro hibernate que a classe GenericDao é para tratar as outras classes no msm pacote
		this.classe = (Class<Entidade>) ((ParameterizedType) getClass().getGenericSuperclass())
				.getActualTypeArguments()[0];
	}
	
	
	

	public void salvar(Entidade entidade) {  //criando um objeto da entidade logo a cima
		Session sessao = HibernateUtil.getSessionFactory().openSession(); //abrindo uma sessao, conforme a documentacao do Hibernate
		Transaction transacao = null; //criando uma transacao para usar no delete,update e insert, um exemplo: quando atualizar o status de uma vaga ele vai atualizar sozinho.
		
		try { //adicionando um try catch caso a transacao der errado 
			
			transacao = sessao.beginTransaction(); //se der errado a transacao sera desfeito
			sessao.save(entidade); //salvando a transacao
			transacao.commit(); //finalizando a transacao
			
			
		} catch (RuntimeException erro) {
			if(transacao !=null) {  //se transacao for diferente de nulo, dar um rollback na transacao
				transacao.rollback();
			}
			throw erro;
			
		}
		finally {
			sessao.close(); //fechando a sessao
		}
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public List<Entidade> listar(){
		Session sessao = HibernateUtil.getSessionFactory().openSession(); //abrindo a sessao
		
		try {
			Criteria consulta = sessao.createCriteria(classe);
			List<Entidade> resultado = consulta.list();
			return resultado;
		} 
		
		catch (RuntimeException erro) {
			throw erro;
		} finally {
			sessao.close();
	}
	
}
	
	
	public void excluir (Entidade entidade) {  //criando um objeto da entidade logo a cima
		Session sessao = HibernateUtil.getSessionFactory().openSession(); //abrindo uma sessao, conforme a documentacao do Hibernate
		Transaction transacao = null; //criando uma transacao para usar no delete,update e insert, um exemplo: quando atualizar o status de uma vaga ele vai atualizar sozinho.
		
		try { //adicionando um try catch caso a transacao der errado 
			
			transacao = sessao.beginTransaction(); //se der errado a transacao sera desfeito
			sessao.delete(entidade); //salvando a transacao
			transacao.commit(); //finalizando a transacao
			
			
		} catch (RuntimeException erro) {
			if(transacao !=null) {  //se transacao for diferente de nulo, dar um rollback na transacao
				transacao.rollback();
			}
			throw erro;
			
		}
		finally {
			sessao.close(); //fechando a sessao
		}
	}
	
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public Entidade buscar(int codigo) {
		Session sessao = HibernateUtil.getSessionFactory().openSession();
		try {
			Criteria consulta = sessao.createCriteria(classe);
			consulta.add(Restrictions.idEq(codigo));
			Entidade resultado = (Entidade) consulta.uniqueResult();
			return resultado;
		} catch (RuntimeException erro) {
			throw erro;
		} finally {
			sessao.close();
		}
	}
	
	
	
	
	public void editar (Entidade entidade) {  //criando um objeto da entidade logo a cima
		Session sessao = HibernateUtil.getSessionFactory().openSession(); //abrindo uma sessao, conforme a documentacao do Hibernate
		Transaction transacao = null; //criando uma transacao para usar no delete,update e insert, um exemplo: quando atualizar o status de uma vaga ele vai atualizar sozinho.
		
		try { //adicionando um try catch caso a transacao der errado 
			
			transacao = sessao.beginTransaction(); //se der errado a transacao sera desfeito
			sessao.update(entidade); //salvando a transacao
			transacao.commit(); //finalizando a transacao
			
			
		} catch (RuntimeException erro) {
			if(transacao !=null) {  //se transacao for diferente de nulo, dar um rollback na transacao
				transacao.rollback();
			}
			throw erro;
			
		}
		finally {
			sessao.close(); //fechando a sessao
		}
	}
	
	
	
	public void merge(Entidade entidade) {  
		Session sessao = HibernateUtil.getSessionFactory().openSession(); 
		Transaction transacao = null;
		
		try { 
			
			transacao = sessao.beginTransaction();
			sessao.merge(entidade);
			transacao.commit(); 
			
			
		} catch (RuntimeException erro) {
			if(transacao !=null) {  
				transacao.rollback();
			}
			throw erro;
			
		}
		finally {
			sessao.close(); 
		}
	}
	
	

	
}


