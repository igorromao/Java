package br.com.estacionamento.bean;

import javax.annotation.PostConstruct;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.omnifaces.util.Messages;
import org.omnifaces.util.Messages.Message;

import br.com.Classes.Vaga;
import br.com.estacionamento.dao.VagaDAO;

import org.omnifaces.util.Messages;




@ManagedBean
@ViewScoped
public class VagaBean {
	

	
	
	private Vaga vaga;
	
	




	public Vaga getVaga() {
		
		return vaga;
	}

	public void setVaga(Vaga vaga) {
		this.vaga = vaga;
	}
	
	
	@PostConstruct
	public void init() {
		
		vaga = new Vaga();
		
		
		
	}

	
	public void salvar() {
		
		VagaDAO vagaDAO = new VagaDAO();
		vagaDAO.salvar(vaga);
		
	Messages.addGlobalInfo("Salvo com Sucesso");
		
		//Messages.addGlobalInfo("Descricao" + vaga.getDescricao());

		
		//String texto = "Cadastrado Com Sucesso";
		//FacesMessage mensagem = new FacesMessage(FacesMessage.SEVERITY_INFO, texto,texto);

		//FacesContext contexto = FacesContext.getCurrentInstance(); // capturando a instancia do JSF
		//contexto.addMessage(null, mensagem);
		
	
	}

}
