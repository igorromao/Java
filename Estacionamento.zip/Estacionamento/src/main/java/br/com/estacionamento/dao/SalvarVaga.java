package br.com.estacionamento.dao;



import br.com.Classes.Vaga;

public class SalvarVaga extends GenericDAO<SalvarVaga> { //herdando da classe genericDAO
	
	
public void salvar() { //criando um metodo salvar
	
	Vaga vaga = new Vaga(); // criando um objeto do tipo vaga
	
	

	vaga.setDescricao("vaga exemplo");
	
	

	

}
	
	
}

	
	


