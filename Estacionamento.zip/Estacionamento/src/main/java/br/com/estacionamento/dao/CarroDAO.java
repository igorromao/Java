package br.com.estacionamento.dao;

import br.com.Classes.Carro;

public class CarroDAO extends GenericDAO<Carro> {

}
