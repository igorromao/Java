package br.com.estacionamento.dao;

import br.com.Classes.Vaga;

public class VagaDAO extends GenericDAO<Vaga> {
	
	
	
	


}
