package br.com.estacionamento.bean;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.omnifaces.util.Messages;

import br.com.Classes.Carro;
import br.com.Classes.Vaga;
import org.omnifaces.util.Messages;
@ManagedBean
@ViewScoped





public class CarroBean {
	
	
	CarroBean carroBean;
	

	private Carro carro;
	
	
public CarroBean() {
		
		carro = new Carro();
		
	}
	
	
	



	public CarroBean getCarroBean() {
		return carroBean;
	}






	public void setCarroBean(CarroBean carroBean) {
		this.carroBean = carroBean;
	}







	public Carro getCarro() {
		return carro;
	}








	public void setCarro(Carro carro) {
		this.carro = carro;
	}

	
	public void novo() {
		carro = new Carro();
	}





	
	public void salvar() {
		
		Messages.addGlobalInfo("Descricao:" +carro.getDescricao() + "Placa" + carro.getPlaca());
		
		
		//String texto = "Cadastrado Com Sucesso";
		
		//FacesMessage mensagem = new FacesMessage("Descricao:" +carro.getDescricao() + "Placa" + carro.getPlaca() );
				
				
				
				//Messages.addGlobalInfo("Descricao" + );
	}

}
