package br.com.estacionamento.util;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class HibernateUtil {
	
	private static SessionFactory sessionFactory = criarsessao();  //criando uma sessao no hibernate e chamando o metodo criar sessao
	
	public static SessionFactory getSessionFactory() {  //criando o get para pegar a sessonfactory
		
		
		
		
		return sessionFactory;
	}
	
	@SuppressWarnings("unused")
	private static SessionFactory criarsessao() {
		
		try {
			Configuration configuracao = new Configuration().configure(); //criando uma configuracao para ler o arquivo Hibernate.cfg
			
			ServiceRegistry registro = new StandardServiceRegistryBuilder().applySettings(configuracao.getProperties()).build(); //pegando as propriedades do Hiberdade.cfg
			
			SessionFactory criacao = configuracao.buildSessionFactory();
			
			
			return criacao;
			
			
		} catch (Throwable ex) {
			System.out.println("nao foi possivel criar  conexao com o Hibernate.cfg");
			throw new ExceptionInInitializerError(ex);
			
			
			
		}
		
	}
	

}
