package br.com.estacionamento.dao;

import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import br.com.Classes.Vaga;

public class VagaDAOTest {

	@Test
	
	public void salvar() {
		Vaga vaga = new Vaga();
		
		vaga.setDescricao("Andrew");
		
		
		
		
		VagaDAO VagaDAO = new VagaDAO();
		VagaDAO.salvar(vaga);
	}
	
	@Ignore
	@SuppressWarnings("unused")
	@Test
	public void listar() {
		VagaDAO vagaDAO = new VagaDAO();
		List<Vaga> resultado = vagaDAO.listar();
		
	}
	
	@Ignore
	@Test
	public void mergeIncluir() {
		Vaga vaga = new Vaga();
		
		vaga.setDescricao("vaga teste");
		
		
		
		
		VagaDAO VagaDAO = new VagaDAO();
		VagaDAO.merge(vaga);
	}
	
	

}
