package br.com.estacionamento.dao;

import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import br.com.Classes.Carro;

public class CarroDAOTest {
	
	
	@Ignore
	@Test
	//@Ignore//ANOTACAO DO JUNIT PARA IGNORAR O TESTE, E TESTAR DE VERDADE
	
	public void salvar() {
		
		Carro carro  = new Carro();
		Carro carro2 = new Carro();
		
		carro.setDescricao("azul");
		carro.setPlaca("pi123378");
		
		
		carro2.setDescricao("preto");
		carro2.setPlaca("abc12345");
		
		CarroDAO carroDAO = new CarroDAO();
		carroDAO.salvar(carro);
		
		CarroDAO carroDAO2 = new CarroDAO();
		carroDAO2.salvar(carro2);
		
	}
	
	@SuppressWarnings("unused")
	@Test
	@Ignore
	public void listar() { //criando um metodo listar
		CarroDAO carroDAO = new CarroDAO();  //criando um objeto da classe carroDAO
		List<Carro> resultado = carroDAO.listar(); //criando uma lista com o nome de resutado e chamando o metodo listar da classe GenercDao 
		
		for(Carro carro : resultado) {  //fazendo um for para percorrer e mostrar a descricao
			System.out.println("Descricao do carro é " + carro.getDescricao()  + " - " + "Placa do Carro é " +  carro.getPlaca());
		}
	}
	
	@Test
	
	public void buscar() {
		int codigo =3;
		
		CarroDAO carroDAO = new CarroDAO(); 
		Carro carro = carroDAO.buscar(codigo);
		
		if(carro ==null) {
			System.out.println("Nenhum ID encontrado");
		}else {
			System.out.println("Registro encontrado:");
		}
		
		System.out.println(carro.getDescricao()  + " - "  +  carro.getPlaca());
		
	}
	
	@Test
	@Ignore
	public void excluir() {
		int codigo =1;
		
		CarroDAO carroDAO = new CarroDAO(); 
		Carro carro = carroDAO.buscar(codigo);
		
		if(carro ==null) {
			System.out.println("Nenhum Registro  encontrado");
			
		}else {
			carroDAO.excluir(carro);
			System.out.println("Registro Excluido:");
			System.out.println(carro.getDescricao()  + " - "  +  carro.getPlaca());
		}
		
		
		
	}
	@Test
	@Ignore
	
	public void editar() {
		int codigo =6;
		
		CarroDAO carroDAO = new CarroDAO(); 
		Carro carro = carroDAO.buscar(codigo);
		
		if(carro ==null) {
			System.out.println("Nenhum Registro  encontrado");
			
		}else {
			System.out.println("Registro editado - Antes:");
			System.out.println(carro.getDescricao()  + " - "  +  carro.getPlaca());
			
			
			carro.setPlaca("igor");
			carro.setDescricao("teste");
			carroDAO.editar(carro);
			
			
		
			System.out.println("Registro editado - Depois:");
			System.out.println(carro.getDescricao()  + " - "  +  carro.getPlaca());
		}
		
		
	
		
	}
		
	}
	

